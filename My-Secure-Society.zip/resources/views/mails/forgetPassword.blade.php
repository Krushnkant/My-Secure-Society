
<!DOCTYPE html>

<html >
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email Template</title>

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,400;0,500;0,700;1,400&display=swap');

        body {
            margin: 0;
            font-family: 'Roboto', sans-serif;
            font-size: 13px;
            line-height: 21px;
            color: #737883;
            background: #f7fbff;
            padding: 0;
            display: flex;align-items: center;justify-content: center;
            min-height: 100vh;
        }
        h1,h2,h3,h4,h5,h6 {
            color: #334257;
        }
        * {
            box-sizing: border-box
        }

        :root {
           --base: #006161
        }

        .main-table {
            width: 500px;
            background: #FFFFFF;
            margin: 0 auto;
            padding: 40px;
        }
        .main-table-td {
        }
        img {
            max-width: 100%;
        }
        .cmn-btn{
            background: var(--base);
            color: #fff;
            padding: 8px 20px;
            display: inline-block;
            text-decoration: none;
        }
        .mb-1 {
            margin-bottom: 5px;
        }
        .mb-2 {
            margin-bottom: 10px;
        }
        .mb-3 {
            margin-bottom: 15px;
        }
        .mb-4 {
            margin-bottom: 20px;
        }
        .mb-5 {
            margin-bottom: 25px;
        }
        hr {
            border-color : rgba(0, 170, 109, 0.3);
            margin: 16px 0
        }
        .border-top {
            border-top: 1px solid rgba(0, 170, 109, 0.3);
            padding: 15px 0 10px;
            display: block;
        }
        .d-block {
            display: block;
        }
        .privacy {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    justify-content: center;
}
.privacy a {
    text-decoration: none;
    color: #334257;
    position: relative;
    margin-left: auto;
    margin-right: auto;
}
.privacy a span {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: #334257;
    display: inline-block;
    margin: 0 7px;
}
        .social {
            margin: 15px 0 8px;
            display: block;
        }
        .copyright{
            text-align: center;
            display: block;
        }
        div {
            display: block;
        }
        a {
            text-decoration: none;
        }
        .text-base {
            color: var(--base);
font-weight: 700
        }
        .mail-img-1 {
            width: 140px;
            height: 60px;
            object-fit: contain
        }
        .mail-img-2 {
            width: 130px;
            height: 45px;
            object-fit: contain
        }
        .mail-img-3 {
            width: 100%;
            height: 172px;
            object-fit: cover
        }
.social img {
width: 24px;    
}
    </style>

</head>


<body style="background-color: #e9ecef;padding:15px">

    <table  class="main-table">
        <tbody>
            <tr>
                <td class="main-table-td">
                    <img class="mail-img-1" src='{{ asset('/image/password.png') }}' id="logoViewer" alt="">
                    <h2 id="mail-title" class="mt-2"> 
                        Change Password Request 
                    </h2>
                    <div class="mb-1" id="mail-body">
                        <div class="mb-1" id="mail-body">
                            <p>The following user has forgotten his password &amp; requested to change/reset their password.&nbsp;</p>
                        </div>
                    </div>
                    @if ($data['url'])
                    <span class="d-block text-center" style="margin-top: 16px">
                    <a href="{{ $data['url']??'#' }}" class="cmn-btn" id="mail-button">{{ $data['url'] }}</a>
                    </span>
                    @endif

                    <hr>
                    <div class="mb-2" id="mail-footer">
                        Please contact us for any queries, we’re always happy to help.
                    </div>
                    <div>
                       Thanks & Regards,
                    </div>
                    <div class="mb-4">
                        {{ $company_name }}
                    </div>
                </td>
            </tr>
            <tr>
                <td>
                    <span class="copyright" id="mail-copyright">
                        Copyright 2024 {{ $company_name }}. All right reserved
                    </span>
                </td>
            </tr>
        </tbody>
    </table>


</body>
</html>

